# AI-First Marketer starter kit

From the talk "From Outcomes to Automation" by Inês Piçarro and Daniele Quartana,
The Global ABM Conference, London, November 4, 2026.

Public builds of what you saw today. No internal data. Yours to adapt.

## What's inside

**Templates/** — five templates, one for each step of "On Monday":

| # | Format | Template | What it's for |
|---|---|---|---|
| 01 | Excel | One slow process | Measure it, then place every step. |
| 02 | PowerPoint | Pilot pitch | Pitch the pilot on one slide. |
| 03 | Word | Knowledge base and first skill | One place the AI reads. One skill that asks first. |
| 04 | Word | Before-it-goes-live check | Five checks before anything goes out. |
| 05 | Excel | Three white lights and red light log | Three checks before a number reaches sales. |

**Marketing Studio skills/** — fifteen Claude skills that take a brief to approved copy.
- Claude desktop app: upload `marketing-studio-starter-plugin.zip` as a plugin, start a new chat, type `/start`.
- Claude.ai on the web: upload each folder in `skills/` as a skill, starting with `house-rules` and `start`.
- Other AI tools: see `docs/other-tools.md`.

Start with template 01. Pick one slow process.

aifirstmarketer.com · basics2ai.com · danielequartana.com
